Please put the following text in document that explains the usage of UAH serial app.

This file contains the text that should follow the UAH serial app demonstration according to demo code number 4 for Lab8.
The source file is named Lab8_D4.c, and UART connection is configured to the following settings.
 * Port : COM1
 * Baud rate : 115200
 * Data bits: 8
 * Parity: None
 * Stop bits: 1
 * Flow Control: None
 
 The demo code utilizes watchdog timer to trigger and interrupt every second. The ISR called increases a floating point value
 by 0.1 every time it is called. When the floating value reaches 9.9,  the value is reset to 0 and the process continues.
 The WDT ISR also sends this value out through UART so that the ramp signal generated can be seen in applications like UAH serial app.
 
The figures with suffix "unedited" are the original screenshots obtained by the use of Lab8_D4.c and UAH serial app.

Following section explains what each of the annotated section mean in the annotated diagrams (.png files):
Settings_annotated.png:
	-> 1: UAH serial app waits until this many samples are received, and then draws in the graph
	-> 2: This indicates the size of packets in bytes that UAH serial app will consider as a packet.
			..in case of Lab8_D4.c, a single precision floating point (4-bytes) data is sent along with a header (1-bytes).
			.. so the Packet Size is set to 5
	-> 3: This indicates the number of data that we want to consider as different channel values. Since it is only one single precision
			.. floating data in our case, number of channel is 1. If we had sent more data along with this floating point, then this number 
			.. would have been 2 or more.
	-> 4: Of the number of channels, this field indicates the properties of channels. Since we have a single channel, there is only field for CH0.
			Single precision floating data (32-bit) is the appropriate selection in this case. [There is another data type of 32 bits. Students are
			advised to try with that data type also and see the difference in graph]
	->5: The count of bytes in a packet start from 0. The way our program in Lab8_D4.c sends the out to UART is as follows
		[<header><floating point>][<header><floating point>...]
		The position of data that we want for floating point in each packet lies at position 1 (position 0 is header)
		
		Also make sure to select the "Show on Graph" check box.
		
firstPage_annotated.png:
	-> 1: Please make sure to configure the settings for UART in this section
	-> 2: Make sure this is checked
	-> 3: Once you are sure, press this button to establish the connection
	-> 4: This is the name of the label that we put in the earlier diagram.
 
